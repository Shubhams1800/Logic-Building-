#include <stdio.h>

void Pattern(int iRow, int iCol) {
    int matrix[iRow][iCol];
    int count = 1;

    for (int i = 0; i < iRow + iCol - 1; i++) {
        if (i < iRow) {
            for (int j = 0; j <= i; j++) {
                if (i - j < iRow && j < iCol) {
                    matrix[i - j][j] = count++;
                }
            }
        } else {
            for (int j = i - iRow + 1; j < iCol; j++) {
                if (i - j < iRow && j < iCol) {
                    matrix[i - j][j] = count++;
                }
            }
        }
    }

    // Printing the pattern
    for (int i = 0; i < iRow; i++) {
        for (int j = 0; j < iCol; j++) {
            if (matrix[i][j] != 0) {
                printf("%d\t", matrix[i][j]);
            }
        }
        printf("\n");
    }
}

int main() {
    int iValue1 = 0, iValue2 = 0;
    printf("Enter number of rows and columns: ");
    scanf("%d %d", &iValue1, &iValue2);
    Pattern(iValue1, iValue2);

    return 0;
}