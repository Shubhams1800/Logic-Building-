#include <stdio.h>
#include <stdlib.h>

void Pattern(int iRow, int iCol) {
    int start = 1;

    for (int i = 0; i < iRow * iCol; i++) {
        printf("%d\n", abs(start));

        if (start > 0) {
            start = -start;
        } else {
            if (start < 0)
                start = abs(start) + 1;
            else
                start = 1;
        }
    }
}

int main() {
    int iValue1 = 0, iValue2 = 0;

    printf("Enter number of rows and columns: ");
    scanf("%d %d", &iValue1, &iValue2);

    Pattern(iValue1, iValue2);

    return 0;
}