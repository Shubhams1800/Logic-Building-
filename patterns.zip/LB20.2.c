#include <stdio.h>

void Pattern(int iRow, int iCol) {
    int matrix[iRow][iCol];
    int count = 1;

    // Filling the matrix with alternating increments
    for (int i = 0; i < iRow; i++) {
        for (int j = 0; j < iCol; j++) {
            if ((i + j) % 2 == 0) {
                matrix[i][j] = count;
                count += 2;
            }
        }
    }

    // Displaying the matrix pattern
    for (int i = 0; i < iRow; i++) {
        for (int j = 0; j < iCol; j++) {
            if (matrix[i][j] != 0) {
                printf("%d\t", matrix[i][j]);
            } else {
                printf("\t");
            }
        }
        printf("\n");
    }
}

int main() {
    int iValue1 = 0, iValue2 = 0;
    printf("Enter number of rows and columns: ");
    scanf("%d %d", &iValue1, &iValue2);
    Pattern(iValue1, iValue2);

    return 0;
}